# coffee > 2025-01-19 10:36am
https://universe.roboflow.com/coffee-ob3d2/coffee-rvxdh

Provided by a Roboflow user
License: CC BY 4.0

